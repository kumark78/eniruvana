<?php
class Registrar_Exception extends Exception
{

}
